#include "main.h"

// Delay function
void delay_us(uint32_t us)
{
  for (uint32_t i = 0; i < (us * 72); i++)  // 72 cycles per microsecond for 72 MHz system clock
  {
    __NOP(); // No operation
  }
}

uint8_t ledPattern[] = {
    0b001,  // State 0 → PA1
    0b010,  // State 1 → PA2
    0b100,  // State 2 → PA3
    0b111   // State 3 → PA1 + PA2 + PA3
};

uint8_t state = 0;
uint8_t lastBtn = 1;
uint8_t buttonPressed = 0;
uint8_t transitionInProgress = 0;

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;

  GPIOA->MODER &= ~(0b11 << (6 * 2));
  GPIOA->MODER |=  (0b01 << (6 * 2));
  GPIOA->OTYPER &= ~(1 << 6);
  GPIOA->PUPDR  &= ~(0b11 << (6 * 2));
  GPIOA->OSPEEDR |= (0b01 << (6 * 2));

  GPIOA->MODER &= ~(0b11 << 2) & ~(0b11 << 4) & ~(0b11 << 6);
  GPIOA->MODER |=  (0b01 << 2) |  (0b01 << 4) |  (0b01 << 6);

  GPIOA->MODER &= ~(0b11 << 0);
  GPIOA->PUPDR &= ~(0b11 << 0);
  GPIOA->PUPDR |=  (0b01 << 0);

  GPIOB->MODER &= ~(0b11 << (10 * 2));
  GPIOB->MODER |=  (0b10 << (10 * 2));
  GPIOB->AFR[1] &= ~(0b1111 << ((10 - 8) * 4));
  GPIOB->AFR[1] |=  (0b0001 << ((10 - 8) * 4));

  TIM2->PSC = 71;
  TIM2->ARR = 20 - 1;
  TIM2->CCR3 = 10;
  TIM2->CCMR2 &= ~(0b111 << 4);
  TIM2->CCMR2 |=  (0b110 << 4);
  TIM2->CCMR2 |= TIM_CCMR2_OC3PE;
  TIM2->CCER |= TIM_CCER_CC3E;
  TIM2->CR1  |= TIM_CR1_ARPE;
  TIM2->EGR  |= TIM_EGR_UG;
  TIM2->CR1  |= TIM_CR1_CEN;

  while (1)
  {
    GPIOA->ODR ^= (1 << 6);
    delay_us(1200);

    uint8_t btn = (GPIOA->IDR >> 0) & 0x01;

    if (btn == 0 && lastBtn == 1 && !buttonPressed && !transitionInProgress)
    {
      buttonPressed = 1;
      transitionInProgress = 1;

      state++;
      if (state >= sizeof(ledPattern)) state = 0;

      GPIOA->ODR &= ~(0b111 << 1);
      GPIOA->ODR |= ((ledPattern[state]) << 1);
    }

    if (btn == 1)
    {
      buttonPressed = 0;
      transitionInProgress = 0;
    }

    lastBtn = btn;
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}
